package com.neko.livewall

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var preview: ImageView
    private lateinit var tvInfo: TextView

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importMedia(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        tvInfo = findViewById(R.id.tvInfo)
        val rg = findViewById<RadioGroup>(R.id.rgScale)
        val sw = findViewById<MaterialSwitch>(R.id.swMute)

        rg.check(if (Prefs.fill(this)) R.id.rbFill else R.id.rbFit)
        sw.isChecked = Prefs.mute(this)

        rg.setOnCheckedChangeListener { _, id -> Prefs.setFill(this, id == R.id.rbFill) }
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setMute(this, checked) }

        findViewById<MaterialButton>(R.id.btnPick).setOnClickListener {
            picker.launch(arrayOf("image/*", "video/*"))
        }
        findViewById<MaterialButton>(R.id.btnApply).setOnClickListener { applyWallpaper() }

        refreshPreview()
    }

    private fun importMedia(uri: Uri) {
        val mime = contentResolver.getType(uri) ?: ""
        val type = when {
            mime == "image/gif" -> Prefs.TYPE_GIF
            mime.startsWith("video/") -> Prefs.TYPE_VIDEO
            mime.startsWith("image/") -> Prefs.TYPE_IMAGE
            else -> {
                Toast.makeText(this, "Formato no compatible 🥺", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
        tvInfo.text = "Importando… ✨"

        thread {
            try {
                filesDir.listFiles { f -> f.name.startsWith("media_") }?.forEach { it.delete() }
                val dest = File(filesDir, "media_${System.currentTimeMillis()}.$ext")
                contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out) }
                } ?: throw IllegalStateException("No se pudo abrir el archivo")
                Prefs.saveMedia(this, dest.absolutePath, type)
                runOnUiThread {
                    refreshPreview()
                    Toast.makeText(this, "¡Listo, mi amor! 💖", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { tvInfo.text = "Error al importar: ${e.message}" }
            }
        }
    }

    private fun refreshPreview() {
        val path = Prefs.path(this)
        val file = path?.let { File(it) }
        if (file == null || !file.exists()) {
            tvInfo.text = "Aún no has elegido nada"
            preview.setImageDrawable(null)
            return
        }
        val type = Prefs.type(this)
        tvInfo.text = "Tipo: ${type.uppercase()} · ${file.length() / 1024} KB"
        try {
            if (type == Prefs.TYPE_VIDEO) {
                val r = MediaMetadataRetriever()
                r.setDataSource(file.absolutePath)
                preview.setImageBitmap(r.getFrameAtTime(0))
                r.release()
            } else {
                val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) { dec, info, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val big = maxOf(info.size.width, info.size.height)
                    if (big > 1600) {
                        val s = 1600f / big
                        dec.setTargetSize(
                            (info.size.width * s).toInt().coerceAtLeast(1),
                            (info.size.height * s).toInt().coerceAtLeast(1)
                        )
                    }
                }
                preview.setImageDrawable(d)
                (d as? AnimatedImageDrawable)?.apply {
                    repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    start()
                }
            }
        } catch (e: Exception) {
            tvInfo.text = "No pude mostrar la vista previa: ${e.message}"
        }
    }

    private fun applyWallpaper() {
        if (Prefs.path(this) == null) {
            Toast.makeText(this, "Primero elige un archivo 🥺", Toast.LENGTH_SHORT).show()
            return
        }
        val component = ComponentName(this, LiveWallpaperService::class.java)
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
            )
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
