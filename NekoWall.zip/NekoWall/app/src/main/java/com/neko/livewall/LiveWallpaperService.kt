package com.neko.livewall

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.max
import kotlin.math.min

class LiveWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MediaEngine()

    inner class MediaEngine : Engine() {

        private val handler = Handler(Looper.getMainLooper())
        private var holder: SurfaceHolder? = null
        private var visible = false

        private var drawable: Drawable? = null
        private var player: MediaPlayer? = null
        private var playerReady = false

        private val prefListener =
            SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> load() }

        private val drawableCallback = object : Drawable.Callback {
            override fun invalidateDrawable(who: Drawable) { if (visible) drawFrame() }
            override fun scheduleDrawable(who: Drawable, what: Runnable, `when`: Long) {
                handler.postAtTime(what, who, `when`)
            }
            override fun unscheduleDrawable(who: Drawable, what: Runnable) {
                handler.removeCallbacks(what, who)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            Prefs.sp(applicationContext).registerOnSharedPreferenceChangeListener(prefListener)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            this.holder = holder
            load()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (player == null) drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            release()
            this.holder = null
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            if (visible) resume() else pause()
        }

        override fun onDestroy() {
            Prefs.sp(applicationContext).unregisterOnSharedPreferenceChangeListener(prefListener)
            release()
            super.onDestroy()
        }

        // ---------- carga ----------

        private fun load() {
            release()
            val h = holder ?: return
            val path = Prefs.path(applicationContext)
            val file = path?.let { File(it) }
            if (file == null || !file.exists()) {
                drawPlaceholder()
                return
            }
            try {
                if (Prefs.type(applicationContext) == Prefs.TYPE_VIDEO) startVideo(file, h)
                else startImage(file)
            } catch (e: Exception) {
                drawPlaceholder()
            }
        }

        private fun startImage(file: File) {
            val metrics = resources.displayMetrics
            val maxDim = max(metrics.widthPixels, metrics.heightPixels) * 2
            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val big = max(info.size.width, info.size.height)
                if (big > maxDim) {
                    val s = maxDim.toFloat() / big
                    decoder.setTargetSize(
                        (info.size.width * s).toInt().coerceAtLeast(1),
                        (info.size.height * s).toInt().coerceAtLeast(1)
                    )
                }
            }
            drawable = d
            if (d is AnimatedImageDrawable) {
                d.callback = drawableCallback
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                if (visible) d.start()
            }
            drawFrame()
        }

        private fun startVideo(file: File, h: SurfaceHolder) {
            val mp = MediaPlayer()
            player = mp
            playerReady = false
            mp.setSurface(h.surface)
            mp.setDataSource(file.absolutePath)
            mp.isLooping = true
            mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
            val vol = if (Prefs.mute(applicationContext)) 0f else 1f
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener {
                playerReady = true
                if (visible) it.start()
            }
            mp.setOnErrorListener { _, _, _ -> true }
            mp.prepareAsync()
        }

        // ---------- ciclo de vida ----------

        private fun resume() {
            val d = drawable
            if (d is AnimatedImageDrawable) d.start()
            if (playerReady) try { player?.start() } catch (_: Exception) {}
            if (player == null) drawFrame()
        }

        private fun pause() {
            val d = drawable
            if (d is AnimatedImageDrawable) d.stop()
            if (playerReady) try { player?.pause() } catch (_: Exception) {}
        }

        private fun release() {
            (drawable as? AnimatedImageDrawable)?.apply { stop(); callback = null }
            drawable = null
            try { player?.release() } catch (_: Exception) {}
            player = null
            playerReady = false
        }

        // ---------- dibujo ----------

        private fun drawPlaceholder() {
            val h = holder ?: return
            var c: Canvas? = null
            try {
                c = h.lockCanvas() ?: return
                c.drawColor(Color.parseColor("#1B1224"))
            } catch (_: Exception) {
            } finally {
                c?.let { h.unlockCanvasAndPost(it) }
            }
        }

        private fun drawFrame() {
            val h = holder ?: return
            val d = drawable ?: return
            var c: Canvas? = null
            try {
                c = h.lockCanvas() ?: return
                c.drawColor(Color.BLACK)
                val iw = d.intrinsicWidth.coerceAtLeast(1)
                val ih = d.intrinsicHeight.coerceAtLeast(1)
                val w = c.width.toFloat()
                val hh = c.height.toFloat()
                val s = if (Prefs.fill(applicationContext)) max(w / iw, hh / ih)
                else min(w / iw, hh / ih)
                c.save()
                c.translate((w - iw * s) / 2f, (hh - ih * s) / 2f)
                c.scale(s, s)
                d.setBounds(0, 0, iw, ih)
                d.draw(c)
                c.restore()
            } catch (_: Exception) {
            } finally {
                c?.let { h.unlockCanvasAndPost(it) }
            }
        }
    }
}
