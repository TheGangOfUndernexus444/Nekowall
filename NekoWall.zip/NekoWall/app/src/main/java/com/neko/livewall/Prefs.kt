package com.neko.livewall

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val TYPE_IMAGE = "image"
    const val TYPE_GIF = "gif"
    const val TYPE_VIDEO = "video"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("nekowall", Context.MODE_PRIVATE)

    fun path(c: Context): String? = sp(c).getString("path", null)
    fun type(c: Context): String = sp(c).getString("type", TYPE_IMAGE) ?: TYPE_IMAGE
    fun fill(c: Context): Boolean = sp(c).getBoolean("fill", true)
    fun mute(c: Context): Boolean = sp(c).getBoolean("mute", true)

    fun saveMedia(c: Context, path: String, type: String) =
        sp(c).edit().putString("path", path).putString("type", type).apply()

    fun setFill(c: Context, v: Boolean) = sp(c).edit().putBoolean("fill", v).apply()
    fun setMute(c: Context, v: Boolean) = sp(c).edit().putBoolean("mute", v).apply()
}
