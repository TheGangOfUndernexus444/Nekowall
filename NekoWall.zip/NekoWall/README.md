# NekoWall
Fondos de pantalla dinámicos para Android: fotos, GIF (y WebP animado) y videos MP4.

## Compilar
1. Abre la carpeta en Android Studio (Koala o más nuevo, JDK 17).
2. Deja que sincronice Gradle (descarga Gradle 8.7 solo).
3. Conecta tu celular (Android 9+) y pulsa Run, o Build > Build APK(s).

## Usar
Elegir archivo -> ajustar modo/silencio -> "Aplicar como fondo" -> confirmar en la vista previa del sistema.
Cambiar de archivo después actualiza el fondo en caliente.
